bin2img
binary to floppy image

Using
bin2img [-i input] [-o output]
      -i:binary file input<default boot.bin>
      -o:image file output<default boot.img>
eg:
      bin2img -i boot.bin -o boot.img
      bin2img -i boot.bin
      bin2img     